package com.example.musicrecomendation.classifiers.behaviors;

public interface ClassifyBehavior {
    float[][] classify(float[] input);
}
