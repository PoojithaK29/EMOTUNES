package com.example.musicrecomendation;

public interface ReceiverListener {
    // create method
    void onNetworkChange(boolean isConnected);
}
